const DEPARTMENTS = [
  {name:'General Medicine',icon:'✚',desc:'General consultations, common illnesses, and primary care.',room:'Block A · Room 101'},
  {name:'Cardiology',icon:'♡',desc:'Heart health consultations and cardiovascular assessment.',room:'Block B · Room 204'},
  {name:'Orthopedics',icon:'✣',desc:'Bone, joint, muscle, and mobility-related consultations.',room:'Block A · Room 118'},
  {name:'Pediatrics',icon:'♧',desc:'Healthcare services for infants, children, and adolescents.',room:'Block C · Room 302'},
  {name:'Diagnostics',icon:'⌁',desc:'Laboratory tests and diagnostic service coordination.',room:'Block D · Lab 01'}
];
const STORE_KEY='careflow_demo_patients_v1';
let patients = [];
try { patients = JSON.parse(localStorage.getItem(STORE_KEY) || '[]'); } catch { patients=[]; }
let activeView='overview';
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function persist(){localStorage.setItem(STORE_KEY,JSON.stringify(patients));}
function initials(name){return name.split(/\s+/).slice(0,2).map(p=>p[0]||'').join('').toUpperCase();}
function statusClass(s){return s.replace(/\s+/g,'-');}
function statusBadge(s){return `<span class="status ${statusClass(s)}">${esc(s)}</span>`;}
function fmtDate(d){return new Date(d).toLocaleDateString(undefined,{month:'short',day:'numeric'});}
function showToast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove('show'),2500);}
function switchView(view){activeView=view;document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden'));$(`#${view}-view`).classList.remove('hidden');document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.view===view));$('#page-title').textContent=({overview:'Overview',patients:'Patients',queue:'Waiting queue',departments:'Departments'})[view];renderAll();}
function openModal(){$('#patient-modal').classList.remove('hidden');$('#patient-form').reset();setTimeout(()=>$('#patient-form [name=name]').focus(),50);}
function closeModal(){$('#patient-modal').classList.add('hidden');}
function renderStats(){$('#stat-total').textContent=patients.filter(p=>p.status!=='Cancelled').length;$('#stat-waiting').textContent=patients.filter(p=>p.status==='Waiting').length;$('#stat-consult').textContent=patients.filter(p=>p.status==='In consultation').length;}
function patientRow(p){return `<tr><td><div class="patient-cell"><div class="avatar">${esc(initials(p.name))}</div><div><b>${esc(p.name)}</b><small>${esc(p.id)}</small></div></div></td><td>${esc(p.department)}</td><td>${esc(p.age)}</td><td>${statusBadge(p.status)}</td><td>${fmtDate(p.createdAt)}</td><td><select class="action-select" aria-label="Update status" onchange="updateStatus('${p.id}',this.value)"><option value="">Update…</option>${['Waiting','In consultation','Completed','Cancelled'].map(s=>`<option ${s===p.status?'disabled':''}>${s}</option>`).join('')}</select></td></tr>`;}
function renderRecent(){const list=[...patients].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,5);$('#recent-list').innerHTML=list.length?`<table><thead><tr><th>PATIENT</th><th>DEPARTMENT</th><th>STATUS</th></tr></thead><tbody>${list.map(p=>`<tr><td><div class="patient-cell"><div class="avatar">${esc(initials(p.name))}</div><div><b>${esc(p.name)}</b><small>${esc(p.id)}</small></div></div></td><td>${esc(p.department)}</td><td>${statusBadge(p.status)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">No patients registered yet. Add a demo patient to get started.</div>';}
function renderPatients(){const q=$('#patient-search').value.toLowerCase();const st=$('#status-filter').value;const arr=[...patients].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).filter(p=>(!st||p.status===st)&&[p.name,p.id,p.phone,p.department].some(v=>String(v||'').toLowerCase().includes(q)));$('#patients-table').innerHTML=arr.length?`<table><thead><tr><th>PATIENT</th><th>DEPARTMENT</th><th>AGE</th><th>STATUS</th><th>REGISTERED</th><th>ACTION</th></tr></thead><tbody>${arr.map(patientRow).join('')}</tbody></table>`:'<div class="empty">No matching patients found.</div>';}
function renderQueue(){const arr=patients.filter(p=>p.status==='Waiting').sort((a,b)=>(a.priority==='Priority review'?-1:0)-(b.priority==='Priority review'?-1:0)||a.createdAt.localeCompare(b.createdAt));$('#queue-count').textContent=`${arr.length} waiting`;$('#queue-list').innerHTML=arr.length?arr.map((p,i)=>`<div class="queue-item"><div class="queue-number">${String(i+1).padStart(2,'0')}</div><div class="queue-info"><b>${esc(p.name)} <span style="font-weight:400;color:#9aa5b5">· ${esc(p.id)}</span></b><small>${esc(p.department)} · ${esc(p.visit)} · ${esc(p.priority)}</small></div><div class="queue-actions"><button class="small-btn" onclick="updateStatus('${p.id}','In consultation')">Start consultation</button><button class="small-btn" onclick="updateStatus('${p.id}','Cancelled')">Cancel</button></div></div>`).join(''):'<div class="empty">The waiting queue is empty.</div>';}
function renderDepartments(){$('#department-grid').innerHTML=DEPARTMENTS.map(d=>`<article class="dept-card"><div class="dept-symbol">${d.icon}</div><h3>${d.name}</h3><p>${d.desc}</p><small>${d.room} · ${patients.filter(p=>p.department===d.name&&p.status!=='Completed'&&p.status!=='Cancelled').length} active patient(s)</small></article>`).join('');}
function renderAll(){renderStats();renderRecent();renderPatients();renderQueue();renderDepartments();}
function updateStatus(id,status){if(!status)return;const p=patients.find(x=>x.id===id);if(!p)return;p.status=status;p.updatedAt=new Date().toISOString();persist();renderAll();showToast(`${p.name}: status updated to ${status}`);}
window.updateStatus=updateStatus;
function registerPatient(e){e.preventDefault();const fd=new FormData(e.target);const name=String(fd.get('name')).trim();if(!name)return;const id='PT-'+String(Date.now()).slice(-7);const p={id,name,age:Number(fd.get('age')),phone:String(fd.get('phone')||'').trim(),department:fd.get('department'),visit:fd.get('visit'),priority:fd.get('priority'),status:'Waiting',createdAt:new Date().toISOString()};patients.push(p);persist();closeModal();renderAll();switchView('patients');showToast(`Patient ${id} registered successfully`);}
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.goto)));
$('#add-top').addEventListener('click',openModal);$('#add-patient').addEventListener('click',openModal);$('#quick-add').addEventListener('click',openModal);$('#close-modal').addEventListener('click',closeModal);
$('#patient-modal').addEventListener('click',e=>{if(e.target.id==='patient-modal')closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
$('#patient-form').addEventListener('submit',registerPatient);$('#patient-search').addEventListener('input',renderPatients);$('#status-filter').addEventListener('change',renderPatients);
$('#today').textContent=new Date().toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric',year:'numeric'});
renderAll();