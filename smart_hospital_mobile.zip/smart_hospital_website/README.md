# CareFlow — Smart Hospital Patient Flow (Mobile-ready)

A responsive, installable mobile web app (PWA) for the Smart Hospital Patient Flow Management student project.

## Open on a phone
- **Quick test:** extract the ZIP and open `index.html` in a mobile browser. Core screens work, but install/offline features require hosting over HTTPS or localhost.
- **Installable app experience:** upload the folder to any static HTTPS host (for example, GitHub Pages) and open the hosted page in Chrome on Android. Use the browser menu and choose **Install app** or **Add to Home screen** when offered.
- You can also open the folder on a computer to preview the desktop layout.

## Features
- Responsive mobile layout for phones and tablets
- Dashboard with patient and queue counts
- Patient registration form with generated patient ID
- Search and filter patient records
- Waiting queue with status updates
- Department directory
- Browser localStorage persistence
- PWA manifest, app icon, and service-worker caching for repeat/offline visits when hosted correctly

## Important limitations
This is a front-end educational prototype. Records are stored only in the current browser and are not synced between devices. It has no authentication, backend, database, encryption, audit logging, or role-based access. Use fictional data only. Queue labels are for UI demonstration and must not be used for clinical triage or medical decisions.

## Files
- `index.html` — page structure and PWA setup
- `style.css` — responsive design
- `app.js` — demo interactions and local storage
- `manifest.json` — installable app metadata
- `service-worker.js` — offline caching
- `icon.svg` — app icon
